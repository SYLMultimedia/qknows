<div class="wrap">
  
  <div class="metabox-holder">

    <div class="postbox" style="padding: 2em; ">
      <p>Talking Website is a free AI powered Widget that 

rapidly installs a chatbot on your website.</p>
<p>With Talking Website, The FAQ is now history as Widget simply converses with your website customers, 

providing the right instant responses,and taking note of their concerns.</p>
<p>Talking Website's backendscript, Knowledge Script (QKnows) also known as INA 

(fire in Yoruba Language) is so simple that anyone can immediately create a very smart chatbot in seconds.</p>
<p>By adopting cutting edge natural language 

precessing techques, Talking Website presenly supports text responses, call to actions, audio responses, speech recognision, gesture controls (premium 

feature), sentiment and entity analysis (premium feature).</p>
<p>Moreover, with 'Quick-E', the custom TW virtual agent, you needn't provide bulky training 

data-sets to enrich your Conversation User Interface (CUI) as she simply reads your website, and learns from your content on the go in addition to dashboard 

training! (premium feature)</p>
<p>When On the virtual assistant mode, the Widget is programmed to really take care of business in your absence, scan for 

business opportunities , feeds you <br />with relevant news, help suggest your next move, and even makes some 'digital marketing' efforts for you!(premium 

feature).</p>
<p>The Talking Website Widget also introduces all the capabilties of the QuickHelp services(www.quickhelp.com.ng) on you website,turning your 

website into a powerful community service hub thereby gaining more visitors.</p>
<p>See how QuickHelp's Talking Website is putting to rest the 'FAQ' with a 

free AI powered website Widget. See Demo here: https://sylmultimedia.com/</p>
<p><br />For more information, call +234 8139737650 or send an email to 

admin@quickhelp.com.ng</p>

      <a href="http://quickhelp.com.ng/https://quickhelp.com.ng/talkingwebsite" target="_blank"> 
      <input type="button" name="" 

value="Vist QuickHelp website for more information" class="btn" style=" cursor: pointer; background-color: #E7E7E7; border: none; padding-top: 10px; 

padding-bottom: 10px; ">
      </a>



    </div>

  </div>
  
</div>

<?php
/*
Plugin Name: QucikHelp's Talking Website
Plugin URI: https://widget.quickhelp.com.ng/dashboard/signup.php
Description: Talking Website is a free AI powered Widget that rapidly installs a chatbot on your website.
Version: 1.0.2
Author: QuickHelp Nigeria
Author URI: https://quickhelp.com.ng/#
License:GPL2          
Text Domain: QucikHelp
*/


add_action('admin_menu', 'my_admin_menu');

function my_admin_menu () {
	
  add_menu_page('QuickHelp Setting', 'QuickHelp', 'manage_options', 'quickhelp_setting_page', 'quickhelp_about_page');


}



function quickhelp_about_page () {
   echo "<h2>" . __( "About QuickHelp's Talking Website" ) . "</h2>";
  include_once('quickhelp_about_page.php');
}


// create custom plugin settings menu
add_action('admin_menu', 'talking_website_plugin_create_menu');

function talking_website_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('Talking Website Settings', 'TW Settings', 'administrator', __FILE__, 'talking_website_plugin_settings_page' , plugins_url('/images/icon.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_talking_website_plugin_settings' );
}


function register_talking_website_plugin_settings() {
	//register our settings
	register_setting( 'tw-plugin-settings-group', 'new_option_name' );
	
}

function talking_website_plugin_settings_page() {
?>
<div class="wrap">
<h1>Talking Website Settings </h1>

<form method="post" action="options.php">
    <?php settings_fields( 'tw-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'tw-plugin-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Chatbot ID</th>
        <td><input type="text" name="new_option_name" value="<?php echo esc_attr( get_option('new_option_name') ); ?>" /></td>
        </tr>
    </table>
		
      <a href="https://widget.quickhelp.com.ng/dashboard/signup.php" target="_blank"> 
      <input type="button" name="" 

value="Click here to get your Talking Website Chatbot ID" class="btn" style=" cursor: pointer; background-color: #E7E7E7; border: none; padding-top: 10px; 

padding-bottom: 10px; ">
      </a>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }


function your_function() {
	$twid = get_option('new_option_name') ;
   include_once('quickhelp_widget.php');
}
add_action( 'wp_footer', 'your_function' );


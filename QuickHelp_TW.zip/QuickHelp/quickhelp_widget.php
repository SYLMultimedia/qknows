 <!--TalkingWebsite Widget Starts --><script>
  window.onload = function (){
    document.getElementById("snackbar2").style.visibility = 'visible';
    document.getElementById("follower").style.visibility = 'hidden';
    };
function hideFrame() {
       document.getElementById("follower").style.visibility = 'hidden';
       document.getElementById("snackbar2").style.visibility = 'visible';
       document.getElementById("later").style.visibility = 'hidden';
    }
    function showFrame() {
        document.getElementById("follower").style.visibility = 'visible';
        document.getElementById("snackbar2").style.visibility = 'hidden';
        document.getElementById("later").style.visibility = 'visible';
    }
</script>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://widget.quickhelp.com.ng/css/stylo.css">
 <div id ="follower">
    
    <iframe src="https://widget.quickhelp.com.ng/index.php?id=<?php echo $twid; ?>" id ="iframe" allowtransparency="true">Sorry but TW widget cannot work on your browzer
    </iframe>
    <div id ="bottonholder">
        <div id="later">
            <button id ="botton" onclick="hideFrame()">Talk later
            </button> 
        </div> 
    </div>
 </div>
<div id="snackbar2">
     <input id ="snackbar" style="background-image:url('https://widget.quickhelp.com.ng/dashboard/uploads/<?php
	 if (empty($twid)){
		 echo "1rw7dgxeh6";
	 } else {
		 echo $twid; 
	 }	    ?>.png')"style="background-image:url('https://widget.quickhelp.com.ng/dashboard/uploads/<?php
   if (empty($twid)){
     echo "1rw7dgxeh6";
   } else {
     echo $twid; 
   }      ?>.jpg')" type="button" onclick="showFrame()" >
 </div><!-- /.TalkingWebsite Widget Ends --> 
     